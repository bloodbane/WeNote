package com.wenote.rest;

public class Constant {

	public static final String accessKey = "AKIAJSOM2BVHJZRMR55Q";
	public static final String secretKey = "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";
	
}
